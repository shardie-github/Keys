"""Tests for jobforge-worker package."""
